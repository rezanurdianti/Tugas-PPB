package com.example.calculatingwombat.interfaces;

public interface ItemTouchHelperViewHolder {
    void onItemSelected();
    void onItemClear();
}
